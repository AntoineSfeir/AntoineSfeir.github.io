Author: Antoine Sfeir
Project: Synth using Tone.js and P5.js

How to use:
- Key to note maping = {Q:C4, W:D4, E:E4, R:F4, T:G4, Y:A4}.
- To change filters for frequency and resonance, move and click to select with the mouse.
- Slider are for volume and Reverb manipulation.
